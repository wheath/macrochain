package com.example.macrochain.RecyclerHome;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.macrochain.R;

import java.util.List;

public class AdapterHome extends RecyclerView.Adapter<ViewHolderHome> {
    Context context;
    List<ItemHome> homeItems;

    public AdapterHome(Context context, List<ItemHome> homeItems) {
        this.context = context;
        this.homeItems = homeItems;
    }

    @NonNull
    @Override
    public ViewHolderHome onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolderHome(LayoutInflater.from(context).inflate(R.layout.view_item_home, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderHome holder, int position) {
        holder.textView.setText(homeItems.get(position).getName());
        holder.imageView.setImageResource(homeItems.get(position).getImage());

        // Listener for clicking on link
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Card Pos " + position, Toast.LENGTH_LONG).show();

//                if (position == 0) {
//                    Intent intent = new Intent(context, PlanAMealActivity.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    context.startActivity(intent);
//                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return homeItems.size();
    }
}
