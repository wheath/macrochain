package com.example.macrochain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }

    /**.
     * Create an account
     */
    public void createAccountActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.signUpButtonS) {
            // Set intent and start new activity
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
    }

    /**.
     * Open new activity/page - Login
     *
     * @param view  the view object
     */
    public void LoginActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.tvLoginSwitchS) {
            // Set intent and start new activity
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
    }
}