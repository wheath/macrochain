package com.example.macrochain.RecyclerSettings;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.macrochain.R;

public class ViewHolderSettings extends RecyclerView.ViewHolder {
    ImageView imageView, arrowView;
    TextView textView;

    public ViewHolderSettings(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageViewSettings);
        textView = itemView.findViewById(R.id.textViewSettings);
        arrowView = itemView.findViewById(R.id.imageViewArrowSettings);
    }
}
