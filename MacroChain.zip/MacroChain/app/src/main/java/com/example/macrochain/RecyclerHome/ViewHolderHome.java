package com.example.macrochain.RecyclerHome;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.macrochain.R;

public class ViewHolderHome extends RecyclerView.ViewHolder {
    ImageView imageView;
    TextView textView;
    CardView cardView;

    public ViewHolderHome(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageViewHome);
        textView = itemView.findViewById(R.id.textViewHome);
        cardView = itemView.findViewById(R.id.cardViewHome);
    }
}
