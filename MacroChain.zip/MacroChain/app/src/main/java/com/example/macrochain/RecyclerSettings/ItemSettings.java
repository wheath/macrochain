package com.example.macrochain.RecyclerSettings;

public class ItemSettings {
    int image, arrow;
    String name;

    public ItemSettings(int image, String name, int arrow) {
        this.image = image;
        this.name = name;
        this.arrow= arrow;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getArrow() {
        return arrow;
    }

    public void setArrow(int arrow) {
        this.arrow = arrow;
    }
}
