package com.example.macrochain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }

    /**.
     * Open new activity/page - Sign Up
     *
     * @param view  the view object
     */
    public void signUpActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.signUpButtonM) {
            // Set intent and start new activity
            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
        }
    }

    /**.
     * Open new activity/page - Log-in
     *
     * @param view  the view object
     */
    public void loginActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.loginButtonM) {
            // Set intent and start new activity
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
    }
}