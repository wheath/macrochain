package com.example.macrochain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    /**.
     * Open Main
     *
     * @param view  the view object
     */
    public void showMainActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.loginButtonL) {
            // Set intent and start new activity
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    /**.
     * Open new activity/page - Sign Up
     *
     * @param view  the view object
     */
    public void signUpActivity(View view) {
        // Set variables
        int thisId = view.getId();

        // If id for button is the same then go to next page/activity
        if (thisId == R.id.tvSignUpSwitchL) {
            // Set intent and start new activity
            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
        }
    }
}