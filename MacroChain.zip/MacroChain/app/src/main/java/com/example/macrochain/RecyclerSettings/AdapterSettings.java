package com.example.macrochain.RecyclerSettings;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.macrochain.R;

import java.util.List;

public class AdapterSettings extends RecyclerView.Adapter<ViewHolderSettings> {
    Context context;
    List<ItemSettings> settingsItems;

    public AdapterSettings(Context context, List<ItemSettings> settingsItems) {
        this.context = context;
        this.settingsItems = settingsItems;
    }

    @NonNull
    @Override
    public ViewHolderSettings onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolderSettings(LayoutInflater.from(context).inflate(R.layout.view_item_settings, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderSettings holder, int position) {
        holder.imageView.setImageResource(settingsItems.get(position).getImage());
        holder.textView.setText(settingsItems.get(position).getName());
        holder.arrowView.setImageResource(settingsItems.get(position).getArrow());
    }

    @Override
    public int getItemCount() {
        return settingsItems.size();
    }
}
